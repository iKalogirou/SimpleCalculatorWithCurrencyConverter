package com.example.todo

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.todo.databinding.ItemToDoBinding

class ToDoAdapter(var todos:List<ToDo>) : RecyclerView.Adapter<ToDoAdapter.ToDoViewHolder> ()
{


    // each adapter for a Recycler View needs to have an inner class, which is a View Holder class,
    // and as the name says, the View Holder is used to hold the views of our Recycle View
    // in this project, the views that we defined in item_to_do.xml file
    inner class ToDoViewHolder(val binding: ItemToDoBinding) : RecyclerView.ViewHolder(binding.root)

    // in the constructor we want to pass the view to our current item,
    //so the view that describes our item at item_to_do.xml file

    // then that class needs to inherit from RecycleView the ViewHolder(*)
    //*: and in that constructor of the ViewHolder we need to pass our item view
    //.. that we pass to our ToDoViewHolder

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ToDoViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding = ItemToDoBinding.inflate(layoutInflater, parent, false)
        return ToDoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ToDoViewHolder, position: Int) {
        holder.binding.apply {
            tvTitle.text = todos[position].title
            cbDone.isChecked = todos[position].isChecked
        }

    }

    override fun getItemCount(): Int {
        return todos.size
    }
}

// also this adapter needs to know which data should send to which item
// that's why we need to make a data class (that describes how the to do item of that list looks like)
// to actually tell this adapter that thing