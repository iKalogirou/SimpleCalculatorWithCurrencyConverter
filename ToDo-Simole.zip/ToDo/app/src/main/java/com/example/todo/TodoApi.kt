package com.example.todo

interface TodoApi {
    
}