package com.example.todo

data class ToDo (
    val title : String,
    var isChecked : Boolean
        )