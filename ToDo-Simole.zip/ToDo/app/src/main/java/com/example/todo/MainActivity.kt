package com.example.todo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.todo.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var toDoList = mutableListOf(
            ToDo("Follow my account", false),
            ToDo("Feed my belly", true),
            ToDo("Get wasted", false)
        )

        val adapter = ToDoAdapter(toDoList)
        binding.rvToDo.adapter = adapter
        binding.rvToDo.layoutManager = LinearLayoutManager(this)

        binding.btnAddToDo.setOnClickListener {
            val title = binding.etToDo.text.toString()
            val todo = ToDo(title,false)
            //add that newly created to do to our to do
            toDoList.add(todo)
            // to update our recycler view
            adapter.notifyItemInserted(toDoList.size-1 )
            binding.etToDo.text.clear()
        }

    }
}